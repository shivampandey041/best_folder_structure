import app from './app.config';
import database from './database.config';
import jwt from './jwt.config';
import email from './email.config';

export default [app, database, jwt, email];
