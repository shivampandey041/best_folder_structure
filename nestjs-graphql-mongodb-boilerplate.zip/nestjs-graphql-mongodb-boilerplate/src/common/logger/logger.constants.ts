export const LOGGER_MODULE_OPTIONS = 'WinstonModuleOptions';
export const LOGGER_MODULE_PROVIDER = 'winston';
export const LOGGER_MODULE_NEST_PROVIDER = 'NestWinston';
