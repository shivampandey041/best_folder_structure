# expressjs-mongodb-typescript-boilerplate

Build with JEST, Mongoose, TypeScript, Commitlint, Eslint, Prettier
