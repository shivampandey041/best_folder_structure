export enum NodeEnv {
  DEVELOPMENT = 'development',
  PRODUCTION = 'production',
  TEST = 'test',
}

export enum UserRoles {
  USER = '0',
  ADMIN = '1',
}
