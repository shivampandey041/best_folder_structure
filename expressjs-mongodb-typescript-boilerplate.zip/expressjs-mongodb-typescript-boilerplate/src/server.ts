import App from './app';

// Initialize Server
App.bootstrap();
