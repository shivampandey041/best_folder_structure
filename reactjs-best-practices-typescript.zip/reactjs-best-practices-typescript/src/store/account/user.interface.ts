export interface IUser {
    email: string;
    password: string
}