export default function Home() {
    return (
      <div className="App">
        <h1>Home Page</h1>
      </div>
    );
  }