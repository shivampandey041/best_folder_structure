

export default function SignUp() {
    return (
      <div className="App">
        <h1>Sign Up Page</h1>
      </div>
    );
  }