import Router from './App.router'

export {Router}