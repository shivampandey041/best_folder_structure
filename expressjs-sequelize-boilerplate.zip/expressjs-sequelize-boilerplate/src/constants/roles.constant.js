const UserRoles = {
  USER: 'user',
  ADMIN: 'admin',
};

module.exports = {
  UserRoles,
};
