const authController = require('./auth.controller');
const userRoleController = require('./user-role.controller');

module.exports = { authController, userRoleController };
