const auth = require('./auth.validation');
const userRole = require('./user-role.validation');

module.exports = {
  auth,
  userRole,
};
