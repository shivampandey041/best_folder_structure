# expressjs-sequelize-boilerplate
NodeJS Sequelize Best Practise
